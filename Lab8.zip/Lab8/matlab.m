format long

f1 = @(x) 3 * atan(x) - x.^2;
f2 = @(x) x.^4 - abs(x) - 1;



%две функции
f1e = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F1_Equidistant.txt');
f1c = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F1_Chebyshev.txt');
f2e = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F2_Equidistant.txt');
f2c = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F2_Chebyshev.txt');

%3 пункт

%Узлы f1
f1_poly5e_k = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F1_Equidistant_5.txt');
f1_poly5c_k = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F1_Chebyshev_5.txt');
f1_poly7e_k = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F1_Equidistant_7.txt');
f1_poly7c_k = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F1_Chebyshev_7.txt');
f1_poly10e_k = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F1_Equidistant_10.txt');
f1_poly10c_k = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F1_Chebyshev_10.txt');

%Узлы f2
f2_poly5e_k = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F2_Equidistant_5.txt');
f2_poly5c_k = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F2_Chebyshev_5.txt');
f2_poly7e_k = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F2_Equidistant_7.txt');
f2_poly7c_k = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F2_Chebyshev_7.txt');
f2_poly10e_k = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F2_Equidistant_10.txt');
f2_poly10c_k = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F2_Chebyshev_10.txt');

% 5 точек
f1_poly5e_l = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F1_Equidistant_N5.txt');
f1_poly5e_l_e = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F1_Equidistant_N5_E.txt');
f1_poly5c_l= load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F1_Chebyshev_N5.txt');
f1_poly5c_l_e = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F1_Chebyshev_N5_E.txt');


f2_poly5e_l = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F2_Equidistant_N5.txt');
f2_poly5e_l_e = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F2_Equidistant_N5_E.txt');
f2_poly5c_l= load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F2_Chebyshev_N5.txt');
f2_poly5c_l_e = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F2_Chebyshev_N5_E.txt');

% Для N=7
f1_poly7e_l = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F1_Equidistant_N7.txt');
f1_poly7e_l_e = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F1_Equidistant_N7_E.txt');
f1_poly7c_l = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F1_Chebyshev_N7.txt');
f1_poly7c_l_e = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F1_Chebyshev_N7_E.txt');

f2_poly7e_l = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F2_Equidistant_N7.txt');
f2_poly7e_l_e = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F2_Equidistant_N7_E.txt');
f2_poly7c_l = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F2_Chebyshev_N7.txt');
f2_poly7c_l_e = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F2_Chebyshev_N7_E.txt');

##% Для N=10
f1_poly10e_l = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F1_Equidistant_N10.txt');
f1_poly10e_l_e = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F1_Equidistant_N10_E.txt');
f1_poly10c_l = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F1_Chebyshev_N10.txt');
f1_poly10c_l_e = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F1_Chebyshev_N10_E.txt');

f2_poly10e_l = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F2_Equidistant_N10.txt');
f2_poly10e_l_e = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F2_Equidistant_N10_E.txt');
f2_poly10c_l = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F2_Chebyshev_N10.txt');
f2_poly10c_l_e = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F2_Chebyshev_N10_E.txt');

%4 пункт

%1 функция
f1_max_l_e = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F1_MaxError_Equidistant.txt');
f1_max_l_c = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F1_MaxError_Chebyshev.txt');


%2 функция
f2_max_l_e = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F2_MaxError_Equidistant.txt');
f2_max_l_c = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/F2_MaxError_Chebyshev.txt');

%1 функция
%точка [3000]

f1_l_e_p1 = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/Function1_Equidistant_Point1.txt');
f1_l_c_p1 = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/Function1_Chebyshev_Point1.txt');

%точка [8000]
f1_l_e_p2 = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/Function1_Equidistant_Point2.txt');
f1_l_c_p2 = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/Function1_Chebyshev_Point2.txt');

%1 функция
%точка [3000]

f2_l_e_p1 = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/Function2_Equidistant_Point1.txt');
f2_l_c_p1 = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/Function2_Chebyshev_Point1.txt');

%точка [8000]
f2_l_e_p2 = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/Function2_Equidistant_Point2.txt');
f2_l_c_p2 = load('/home/masha/numerical_methods/Lab8/lab8_proj/cmake-build-debug/Function2_Chebyshev_Point2.txt');



##figure;
##hold on;
##grid on;
##xlim([-2,2]);
##plot(f1e(:,1), f1e(:,2));
##plot(f1_poly5e_l(:,1),f1_poly5e_l(:,2));
##plot(f1_poly7e_l(:,1),f1_poly7e_l(:,2));
##plot(f1_poly10e_l(:,1),f1_poly10e_l(:,2));
##
##plot(f1_poly5e_k(:,1),f1_poly5e_k(:,2),'kx');
##plot(f1_poly7e_k(:,1),f1_poly7e_k(:,2),'ko');
##plot(f1_poly10e_k(:,1),f1_poly10e_k(:,2),'k*');
####
##legend("Функция 1","Полином 5 узлов","Полином 7 узлов","Полином 10 узлов","Узлы полинома 4 степени", "Узлы полинома 6 степени","Узлы полинома 9 степени");
##title("(Метод Ньютона) Интерполяционные полиномы для равномерной сетки для первой функции");
##xlabel("Ось X");
##ylabel("Ось Y");
######
##figure;
##hold on;
##grid on;
##xlim([-2,2]);
##plot(f1c(:,1), f1c(:,2));
##plot(f1_poly5c_l(:,1),f1_poly5c_l(:,2));
##plot(f1_poly7c_l(:,1),f1_poly7c_l(:,2));
##plot(f1_poly10c_l(:,1),f1_poly10c_l(:,2));
##
##plot(f1_poly5c_k(:,1),f1_poly5c_k(:,2),'kx');
##plot(f1_poly7c_k(:,1),f1_poly7c_k(:,2),'ko');
##plot(f1_poly10c_k(:,1),f1_poly10c_k(:,2),'k*');
##
##legend("Функция 1","Полином 5 узлов","Полином 7 узлов","Полином 10 узлов","Узлы полинома 4 степени", "Узлы полинома 6 степени","Узлы полинома 9 степени");
##title("(Метод Ньютона) Интерполяционные полиномы для чебышевской сетки для первой функции");
##xlabel("Ось X");
##ylabel("Ось Y");
##
##figure;
##hold on;
##grid on;
##xlim([-1,1]);
##plot(f2e(:,1), f2e(:,2));
##plot(f2_poly5e_l(:,1),f2_poly5e_l(:,2));
##plot(f2_poly7e_l(:,1),f2_poly7e_l(:,2));
##plot(f2_poly10e_l(:,1),f2_poly10e_l(:,2));
##
##plot(f2_poly5e_k(:,1),f2_poly5e_k(:,2),'kx');
##plot(f2_poly7e_k(:,1),f2_poly7e_k():,2),'ko');
##plot(f2_poly10e_k(:,1),f2_poly10e_k(:,2),'k*');
##
##legend("Функция 2","Полином 5 узлов","Полином 7 узлов","Полином 10 узлов","Узлы полинома 4 степени", "Узлы полинома 6 степени","Узлы полинома 9 степени");
##title("(Метод Ньютона) Интерполяционные полиномы для равномерной сетки для функции второй функции");
##xlabel("Ось X");
##ylabel("Ось Y");
####
##figure;
##hold on;
##grid on;
##xlim([-1,1]);
##plot(f2c(:,1), f2c(:,2));
##plot(f2_poly5c_l(:,1),f2_poly5c_l(:,2));
##plot(f2_poly7c_l(:,1),f2_poly7c_l(:,2)));
##plot(f2_poly10c_l(:,1),f2_poly10c_l(:,2));
##
##plot(f2_poly5c_k(:,1),f2_poly5c_k(:,2),'kx');
##plot(f2_poly7c_k(:,1),f2_poly7c_k(:,2),'ko');
##plot(f2_poly10c_k(:,1),f2_poly10c_k(:,2),'k*');
##
##legend("Функция 2","Полином 5 узлов","Полином 7 узлов","Полином 10 узлов","Узлы полинома 4 степени", "Узлы полинома 6 степени","Узлы полинома 9 степени");
##title("(Метод Ньютона) Интерполяционные полиномы для чебышевской сетки для функции второй функции");
##xlabel("Ось X");
##ylabel("Ось Y");

##f5 = @(x) 72 * (1 - 12 * x.^2 / (1 + x.^2) + 16 * x.^4 / (1 + x.^2).^2) / (1 + x.^2).^3;
##f5_point = f5(0);
##
##% Инициализация вектора для хранения теоретической ошибки
##E_n_vals = zeros(size(f1_poly5e_l));
##% Расчет теоретической ошибки в заданных точках
##for i = 1:length(f1_poly5e_l)
##    x_val = f1_poly5e_l(i);  % Точка, где оцениваем ошибку
##
##    % Инициализация произведения (x - x_i)
##    error_prod = 1;
##
##    % Вычисление произведения (x_val - x_j) для всех узлов
##    for j = 1:length(f1_poly5e_k)
##        error_prod = error_prod * (x_val - f1_poly5e_k(j));
##    end
##
##    % Теоретическая ошибка для текущей точки
##    E_n_vals(i) = abs(f5_point / factorial(5) * error_prod);
##end


##figure;
##hold on;
##grid on;
##xlim([-2,2]);
##plot(f1_poly5e_l_e(:,1),f1_poly5e_l_e(:,2));
##plot(f1_poly7e_l_e(:,1),f1_poly7e_l_e(:,2));
##plot(f1_poly10e_l_e(:,1),f1_poly10e_l_e(:,2));
##plot(f1_poly5e_l(:,1),E_n_vals);
##legend("Поточечная ошибка для 5 узлов", "Поточечная ошибка для 7 узлов","Поточечная ошибка для 10 узлов","График теоретической ошибки для 5 узлов");
##title("График ошибок  5,7,10 узловых полиномов для первой функции для равномерной сетки");
##xlabel("График X");
##ylabel("График Y");
##



##E_n_vals = zeros(size(f1_poly5c_l));
##% Расчет теоретической ошибки в заданных точках
##for i = 1:length(f1_poly5c_l)
##    x_val = f1_poly5c_l(i);  % Точка, где оцениваем ошибку
##
##    % Инициализация произведения (x - x_i)
##    error_prod = 1;
##
##    % Вычисление произведения (x_val - x_j) для всех узлов
##    for j = 1:length(f1_poly5c_k)
##        error_prod = error_prod * (x_val - f1_poly5c_k(j));
##    end
##
##    % Теоретическая ошибка для текущей точки
##    E_n_vals(i) = abs(f5_point / factorial(5) * error_prod);
##end
##
##figure;
##hold on;
##grid on;
##xlim([-2,2]);
##plot(f1_poly5c_l_e(:,1),f1_poly5c_l_e(:,2));
##plot(f1_poly7c_l_e(:,1),f1_poly7c_l_e(:,2));
##plot(f1_poly10c_l_e(:,1),f1_poly10c_l_e(:,2));
##plot(f1_poly5c_l(:,1),E_n_vals);
##legend("Поточечная ошибка для 5 узлов", "Поточечная ошибка для 7 узлов","Поточечная ошибка для 10 узлов","График теоретической ошибки для 5 узлов");
##title("График ошибок  5,7,10 узловых полиномов для первой функции для Чебышевской сетки");
##xlabel("График X");
##ylabel("График Y");




##figure;
##hold on;
##grid on;
##xlim([-1,1]);
##plot(f2_poly5e_l_e(:,1),f2_poly5e_l_e(:,2));
##plot(f2_poly7e_l_e(:,1),f2_poly7e_l_e(:,2));
##plot(f2_poly10e_l_e(:,1),f2_poly10e_l_e(:,2));
##legend("Поточечная ошибка для 5 узлов","Поточечная ошибка для 7 узлов", "Поточечная ошибка для 10 узлов");
##title("График ошибок  5,7,10 узловых полиномов для второй функции для равномерной сетки");
##xlabel("График X");
##ylabel("График Y");
####
##figure;
##hold on;
##grid on;
##xlim([-1,1]);
##plot(f2_poly5c_l_e(:,1),f2_poly5c_l_e(:,2));
##plot(f2_poly7c_l_e(:,1),f2_poly7c_l_e(:,2));
##plot(f2_poly10c_l_e(:,1),f2_poly10c_l_e(:,2));
##legend("Поточечная ошибка для 5 узлов","Поточечная ошибка для 7 узлов", "Поточечная ошибка для 10 узлов");
##title("График ошибок  5,7,10 узловых полиномов для второй функции для Чебышевской сетки");
##xlabel("График X");
##ylabel("График Y");


figure;
grid on;
xlim([5,100]);
semilogy(f1_max_l_e(:,1),f1_max_l_e(:,2));
ylabel('Максимальная ошибка');
xlabel('Количество узлов');
title("Максимальная ошибка интерполяционного полинома в зависимости от количества узлов для равномерной сетки для первой функции")





figure;
grid on;
xlim([5,100]);
semilogy(f1_max_l_c(:,1),f1_max_l_c(:,2));
ylabel('Максимальная ошибка');
xlabel('Количество узлов');
title("Максимальная ошибка интерполяционного полинома в зависимости от количества узлов для чебышевской сетки для первой функции")

figure;
grid on;
xlim([5,100]);
semilogy(f2_max_l_e(:,1),f2_max_l_e(:,2));
ylabel('Максимальная ошибка');
xlabel('Количество узлов');
title("Максимальная ошибка интерполяционного полинома в зависимости от количества узлов для равномерной сетки для второй функции")



figure;
grid on;
xlim([5,100]);
semilogy(f2_max_l_c(:,1),f2_max_l_c(:,2));
ylabel('Максимальная ошибка');
xlabel('Количество узлов');
title("Максимальная ошибка интерполяционного полинома в зависимости от количества узлов для чебышевской сетки для второй функции")

figure;
grid on;
xlim([5,100]);
semilogy(f1_l_e_p1(:,1),f1_l_e_p1(:,2));
title("Зависимость ошибки в точке -0.7998799879988 для равномерной сетки для функции 1")
xlabel("Количество узлов");
ylabel("Максимальная ошбка")

figure;
grid on;
xlim([5,100]);
semilogy(f1_l_c_p1(:,1),f1_l_c_p1(:,2));
title("Зависимость ошибки в точке 1.175316329898365 для Чебышевской сетки для функции 1")
xlabel("Количество узлов");
ylabel("Максимальная ошбка")





figure;
grid on;
xlim([5,100]);
semilogy(f1_l_e_p2(:,1),f1_l_e_p2(:,2));
title("Зависимость ошибки в точке 1.2003200320032 для равномерной сетки для функции 1")
xlabel("Количество узлов");
ylabel("Максимальная ошбка")


figure;
grid on;
xlim([5,100]);
semilogy(f1_l_c_p2(:,1),f1_l_c_p2(:,2));
title("Зависимость ошибки в точке -1.61821862697049 для Чебышевской сетки для функции 1")
xlabel("Количество узлов");
ylabel("Максимальная ошбка")





figure;
grid on;
xlim([5,100]);
semilogy(f2_l_e_p1(:,1),f2_l_e_p1(:,2));
title("Зависимость ошибки в точке -0.3999399939994 для равномерной сетки для функции 2")
xlabel("Количество узлов");
ylabel("Максимальная ошбка")


figure;
grid on;
xlim([5,100]);
semilogy(f2_l_c_p1(:,1),f2_l_c_p1(:,2));
title("Зависимость ошибки в точке 0.587658164949178 для Чебышевской сетки для функции 2")
xlabel("Количество узлов");
ylabel("Максимальная ошбка")



figure;
grid on;
xlim([5,100]);
semilogy(f2_l_e_p2(:,1),f2_l_e_p2(:,2));
title("Зависимость ошибки в точке 0.6001600160016 для равномерной сетки для функции 2")
xlabel("Количество узлов");
ylabel("Максимальная ошбка")


figure;
grid on;
xlim([5,100]);
semilogy(f2_l_c_p2(:,1),f2_l_c_p2(:,2));
title("Зависимость ошибки в точке -0.809109313485245 для Чебышевской для функции 2")
xlabel("Количество узлов");
ylabel("Максимальная ошбка")


