#include <fstream>
#include <iomanip>
#include <iostream>
#include <cmath>
#include <string>
#include <ctime>
using namespace std;
#define PI 3.14159265358979323846


double f1(double x) {
    return 3 * atan(x) - x * x;
}

double f2(double x) {
    return pow(x, 4) - abs(x) - 1;
}

void CreateEquidistantGrid(double **Grid, double a, double b, int n) {
    double h = ((b - a) / (n - 1));
    *Grid = new double[n];
    if (*Grid == nullptr) {
        throw runtime_error("Memory allocation failed");
    }
    for (int i = 0; i < n; i++) {
        (*Grid)[i] = a + i * h;
    }
}

void CreateChebyshevGrid(double **Grid, double a, double b, int n) {
    double n1 = (b - a) / 2;
    double n2 = (a + b) / 2;
    *Grid = new double[n];
    if (*Grid == nullptr) {
        throw runtime_error("Memory allocation failed");
    }
    for (int i = 0; i < n; i++) {
        (*Grid)[i] = (n1 * cos(PI * (2 * i + 1) / (2 * n))) + n2;
    }
}

void CalcGridY(double (*f)(double), double **GridX, double **GridY, int n) {
    *GridY = new double[n];
    if (*GridY == nullptr) {
        throw runtime_error("Memory allocation failed");
    }
    for (int i = 0; i < n; i++) {
        (*GridY)[i] = f((*GridX)[i]);
    }
}

void CalculateNewtonCoefficientsBackwards(double **C, double **GridX, double **GridY, int n) {
    *C = (double *) malloc(sizeof(double) * (n + 1));
    double term = 0, q = 1;
    if (*C == NULL) {
        printf("Îøèáêà âûäåëåíèÿ ïàìÿòè!");
        return;
    } else {
        (*C)[0] = (*GridY)[n - 1];
        (*C)[1] = ((*GridY)[n - 2] - (*GridY)[n - 1]) / ((*GridX)[n - 2] - (*GridX)[n - 1]);
        term = 0;
        for (int k = n - 3; k >= 0; k--) {
            term = 0;
            for (int j = k; j < n - 1; j++) {
                q = 1;
                for (int i = k; i < n - 1; i++) {
                    if (i != j) {
                        q = q * ((*GridX)[j] - (*GridX)[i]);
                    }
                }
                term += (*GridY)[j] / q;
            }
            (*C)[n - 1 - k] = (term - (*C)[n - 2 - k]) / ((*GridX)[k] - (*GridX)[n - 1]);
        }
    }
}

double NewtonInterpolationResultBackwards(double X, double *GridX, double *Coeff, int n) {
    double term = Coeff[0], q = 1;
    for (int i = 1; i < n; i++) {
        q = 1;
        for (int j = n - i; j < n; j++) {
            q = q * (X - GridX[j]);
        }
        term += Coeff[i] * q;
    }
    return term;
}

void WriteDataSetToFile(const string &filename, double *GridX, double *GridY, int n) {
    ofstream file(filename);
    if (!file) {
        throw runtime_error("Could not open file for writing.");
    }
    file << fixed << setprecision(15);
    for (int i = 0; i < n; i++) {
        file << GridX[i] << ' ' << GridY[i] << '\n';
    }
}

int main(void) {
    double *TestEquiGrid1 = NULL, *TestYEquiGrid1 = NULL, *TestChebyshevGrid1 = NULL, *TestYChebyshevGrid1 = NULL;
    double *TestEquiGrid2 = NULL, *TestYEquiGrid2 = NULL, *TestChebyshevGrid2 = NULL, *TestYChebyshevGrid2 = NULL;
    double *EquidistantGrid = NULL, *EquidistantYGrid = NULL, *EquidistantGrid2 = NULL, *EquidistantYGrid2 = NULL;
    double *ChebyshevGrid = NULL, *ChebyshevYGrid = NULL, *ChebyshevGrid2 = NULL, *ChebyshevYGrid2 = NULL;
    double *NTCoeff = NULL, *NTCoeffC = NULL, *NTCoeff2 = NULL, *NTCoeffC2 = NULL;

    const string F1GE = "F1_Equidistant.txt";
    const string F1GC = "F1_Chebyshev.txt";
    const string F2GE = "F2_Equidistant.txt";
    const string F2GC = "F2_Chebyshev.txt";

    CreateEquidistantGrid(&TestEquiGrid1, -2, 2, 10000);
    CreateChebyshevGrid(&TestChebyshevGrid1, -2, 2, 10000);
    CalcGridY(f1, &TestEquiGrid1, &TestYEquiGrid1, 10000);
    CalcGridY(f1, &TestChebyshevGrid1, &TestYChebyshevGrid1, 10000);
    CreateEquidistantGrid(&TestEquiGrid2, -1, 1, 10000);
    CreateChebyshevGrid(&TestChebyshevGrid2, -1, 1, 10000);
    CalcGridY(f2, &TestEquiGrid2, &TestYEquiGrid2, 10000);
    CalcGridY(f2, &TestChebyshevGrid2, &TestYChebyshevGrid2, 10000);

    WriteDataSetToFile(F1GE, TestEquiGrid1, TestYEquiGrid1, 10000);
    WriteDataSetToFile(F1GC, TestChebyshevGrid1, TestYChebyshevGrid1, 10000);
    WriteDataSetToFile(F2GE, TestEquiGrid2, TestYEquiGrid2, 10000);
    WriteDataSetToFile(F2GC, TestChebyshevGrid2, TestYChebyshevGrid2, 10000);


    const string F15E = "F1_Equidistant_5.txt";
    const string F15C = "F1_Chebyshev_5.txt";
    const string F25E = "F2_Equidistant_5.txt";
    const string F25C = "F2_Chebyshev_5.txt";

    const string F1N5E = "F1_Equidistant_N5.txt";
    const string F1N5C = "F1_Chebyshev_N5.txt";
    const string F2N5E = "F2_Equidistant_N5.txt";
    const string F2N5C = "F2_Chebyshev_N5.txt";

    const string F1N5E_E = "F1_Equidistant_N5_E.txt";
    const string F1N5C_E = "F1_Chebyshev_N5_E.txt";
    const string F2N5E_E = "F2_Equidistant_N5_E.txt";
    const string F2N5C_E = "F2_Chebyshev_N5_E.txt";


    CreateEquidistantGrid(&EquidistantGrid, -2, 2, 5);
    CreateChebyshevGrid(&ChebyshevGrid, -2, 2, 5);
    CalcGridY(f1, &EquidistantGrid, &EquidistantYGrid, 5);
    CalcGridY(f1, &ChebyshevGrid, &ChebyshevYGrid, 5);
    WriteDataSetToFile(F15E, EquidistantGrid, EquidistantYGrid, 5);
    WriteDataSetToFile(F15C, ChebyshevGrid, ChebyshevYGrid, 5);

    CalculateNewtonCoefficientsBackwards(&NTCoeff, &EquidistantGrid, &EquidistantYGrid, 5);
    CalculateNewtonCoefficientsBackwards(&NTCoeffC, &ChebyshevGrid, &ChebyshevYGrid, 5);

    // Second set of calculations
    CreateEquidistantGrid(&EquidistantGrid2, -1, 1, 5);
    CreateChebyshevGrid(&ChebyshevGrid2, -1, 1, 5);
    CalcGridY(f2, &EquidistantGrid2, &EquidistantYGrid2, 5);
    CalcGridY(f2, &ChebyshevGrid2, &ChebyshevYGrid2, 5);
    CalculateNewtonCoefficientsBackwards(&NTCoeff2, &EquidistantGrid2, &EquidistantYGrid2, 5);
    CalculateNewtonCoefficientsBackwards(&NTCoeffC2, &ChebyshevGrid2, &ChebyshevYGrid2, 5);
    WriteDataSetToFile(F25E, EquidistantGrid2, EquidistantYGrid2, 5);
    WriteDataSetToFile(F25C, ChebyshevGrid2, ChebyshevYGrid2, 5);


    ofstream F1N5EFile(F1N5E);
    ofstream F1N5CFile(F1N5C);
    ofstream F2N5EFile(F2N5E);
    ofstream F2N5CFile(F2N5C);

    ofstream F1N5E_E_File(F1N5E_E);
    ofstream F1N5C_E_File(F1N5C_E);
    ofstream F2N5E_E_File(F2N5E_E);
    ofstream F2N5C_E_File(F2N5C_E);


    for (int i = 0; i < 10000; i++) {
        // For the first grid
        double x = TestEquiGrid1[i];
        double y = TestYEquiGrid1[i];
        double xc = TestChebyshevGrid1[i];
        double yc = TestYChebyshevGrid1[i];

        double tmpl = NewtonInterpolationResultBackwards(x, EquidistantGrid, NTCoeff, 5);
        double tmplc = NewtonInterpolationResultBackwards(xc, ChebyshevGrid, NTCoeffC, 5);
        double tmple = fabs(y - tmpl);
        double tmplec = fabs(yc - tmplc);

        // Writing results to files
        F1N5EFile << x << " " << tmpl << "\n";
        F1N5CFile << xc << " " << tmplc << "\n";
        F1N5E_E_File << x << " " << tmple << "\n";
        F1N5C_E_File << xc << " " << tmplec << "\n";

        // For the second grid
        double x2 = TestEquiGrid2[i];
        double y2 = TestYEquiGrid2[i];
        double xc2 = TestChebyshevGrid2[i];
        double yc2 = TestYChebyshevGrid2[i];

        double tmpl2 = NewtonInterpolationResultBackwards(x2, EquidistantGrid2, NTCoeff2, 5);
        double tmplc2 = NewtonInterpolationResultBackwards(xc2, ChebyshevGrid2, NTCoeffC2, 5);
        double tmple2 = fabs(y2 - tmpl2);
        double tmplec2 = fabs(yc2 - tmplc2);

        // Writing results to files
        F2N5EFile << x2 << " " << tmpl2 << "\n";
        F2N5CFile << xc2 << " " << tmplc2 << "\n";
        F2N5E_E_File << x2 << " " << tmple2 << "\n";
        F2N5C_E_File << xc2 << " " << tmplec2 << "\n";
    }

    // Close files
    F1N5EFile.close();
    F1N5CFile.close();
    F2N5EFile.close();
    F2N5CFile.close();
    //
    const string F17E = "F1_Equidistant_7.txt";
    const string F17C = "F1_Chebyshev_7.txt";
    const string F27E = "F2_Equidistant_7.txt";
    const string F27C = "F2_Chebyshev_7.txt";

    const string F1N7E = "F1_Equidistant_N7.txt";
    const string F1N7C = "F1_Chebyshev_N7.txt";
    const string F2N7E = "F2_Equidistant_N7.txt";
    const string F2N7C = "F2_Chebyshev_N7.txt";

    const string F1N7E_E = "F1_Equidistant_N7_E.txt";
    const string F1N7C_E = "F1_Chebyshev_N7_E.txt";
    const string F2N7E_E = "F2_Equidistant_N7_E.txt";
    const string F2N7C_E = "F2_Chebyshev_N7_E.txt";

    // Create and calculate grids
    CreateEquidistantGrid(&EquidistantGrid, -2, 2, 7);
    CreateChebyshevGrid(&ChebyshevGrid, -2, 2, 7);
    CalcGridY(f1, &EquidistantGrid, &EquidistantYGrid, 7);
    CalcGridY(f1, &ChebyshevGrid, &ChebyshevYGrid, 7);
    WriteDataSetToFile(F17E, EquidistantGrid, EquidistantYGrid, 7);
    WriteDataSetToFile(F17C, ChebyshevGrid, ChebyshevYGrid, 7);

    CalculateNewtonCoefficientsBackwards(&NTCoeff, &EquidistantGrid, &EquidistantYGrid, 7);
    CalculateNewtonCoefficientsBackwards(&NTCoeffC, &ChebyshevGrid, &ChebyshevYGrid, 7);

    // Second set of calculations
    CreateEquidistantGrid(&EquidistantGrid2, -1, 1, 7);
    CreateChebyshevGrid(&ChebyshevGrid2, -1, 1, 7);
    CalcGridY(f2, &EquidistantGrid2, &EquidistantYGrid2, 7);
    CalcGridY(f2, &ChebyshevGrid2, &ChebyshevYGrid2, 7);
    CalculateNewtonCoefficientsBackwards(&NTCoeff2, &EquidistantGrid2, &EquidistantYGrid2, 7);
    CalculateNewtonCoefficientsBackwards(&NTCoeffC2, &ChebyshevGrid2, &ChebyshevYGrid2, 7);
    WriteDataSetToFile(F27E, EquidistantGrid2, EquidistantYGrid2, 7);
    WriteDataSetToFile(F27C, ChebyshevGrid2, ChebyshevYGrid2, 7);

    ofstream F1N7EFile(F1N7E);
    ofstream F1N7CFile(F1N7C);
    ofstream F2N7EFile(F2N7E);
    ofstream F2N7CFile(F2N7C);

    ofstream F1N7E_E_File(F1N7E_E);
    ofstream F1N7C_E_File(F1N7C_E);
    ofstream F2N7E_E_File(F2N7E_E);
    ofstream F2N7C_E_File(F2N7C_E);


    for (int i = 0; i < 10000; i++) {
        // For the first grid
        double x = TestEquiGrid1[i];
        double y = TestYEquiGrid1[i];
        double xc = TestChebyshevGrid1[i];
        double yc = TestYChebyshevGrid1[i];

        double tmpl = NewtonInterpolationResultBackwards(x, EquidistantGrid, NTCoeff, 7);
        double tmplc = NewtonInterpolationResultBackwards(xc, ChebyshevGrid, NTCoeffC, 7);
        double tmple = fabs(y - tmpl);
        double tmplec = fabs(yc - tmplc);

        // Writing results to files
        F1N7EFile << x << " " << tmpl << "\n";
        F1N7CFile << xc << " " << tmplc << "\n";
        F1N7E_E_File << x << " " << tmple << "\n";
        F1N7C_E_File << xc << " " << tmplec << "\n";

        // For the second grid
        double x2 = TestEquiGrid2[i];
        double y2 = TestYEquiGrid2[i];
        double xc2 = TestChebyshevGrid2[i];
        double yc2 = TestYChebyshevGrid2[i];

        double tmpl2 = NewtonInterpolationResultBackwards(x2, EquidistantGrid2, NTCoeff2, 7);
        double tmplc2 = NewtonInterpolationResultBackwards(xc2, ChebyshevGrid2, NTCoeffC2, 7);
        double tmple2 = fabs(y2 - tmpl2);
        double tmplec2 = fabs(yc2 - tmplc2);

        // Writing results to files
        F2N7EFile << x2 << " " << tmpl2 << "\n";
        F2N7CFile << xc2 << " " << tmplc2 << "\n";
        F2N7E_E_File << x2 << " " << tmple2 << "\n";
        F2N7C_E_File << xc2 << " " << tmplec2 << "\n";
    }


    const string F110E = "F1_Equidistant_10.txt";
    const string F110C = "F1_Chebyshev_10.txt";
    const string F210E = "F2_Equidistant_10.txt";
    const string F210C = "F2_Chebyshev_10.txt";

    const string F1N10E = "F1_Equidistant_N10.txt";
    const string F1N10C = "F1_Chebyshev_N10.txt";
    const string F2N10E = "F2_Equidistant_N10.txt";
    const string F2N10C = "F2_Chebyshev_N10.txt";

    const string F1N10E_E = "F1_Equidistant_N10_E.txt";
    const string F1N10C_E = "F1_Chebyshev_N10_E.txt";
    const string F2N10E_E = "F2_Equidistant_N10_E.txt";
    const string F2N10C_E = "F2_Chebyshev_N10_E.txt";

    // Create and calculate grids
    CreateEquidistantGrid(&EquidistantGrid, -2, 2, 10);
    CreateChebyshevGrid(&ChebyshevGrid, -2, 2, 10);
    CalcGridY(f1, &EquidistantGrid, &EquidistantYGrid, 10);
    CalcGridY(f1, &ChebyshevGrid, &ChebyshevYGrid, 10);
    WriteDataSetToFile(F110E, EquidistantGrid, EquidistantYGrid, 10);
    WriteDataSetToFile(F110C, ChebyshevGrid, ChebyshevYGrid, 10);

    CalculateNewtonCoefficientsBackwards(&NTCoeff, &EquidistantGrid, &EquidistantYGrid, 10);
    CalculateNewtonCoefficientsBackwards(&NTCoeffC, &ChebyshevGrid, &ChebyshevYGrid, 10);

    // Second set of calculations
    CreateEquidistantGrid(&EquidistantGrid2, -1, 1, 10);
    CreateChebyshevGrid(&ChebyshevGrid2, -1, 1, 10);
    CalcGridY(f2, &EquidistantGrid2, &EquidistantYGrid2, 10);
    CalcGridY(f2, &ChebyshevGrid2, &ChebyshevYGrid2, 10);
    CalculateNewtonCoefficientsBackwards(&NTCoeff2, &EquidistantGrid2, &EquidistantYGrid2, 10);
    CalculateNewtonCoefficientsBackwards(&NTCoeffC2, &ChebyshevGrid2, &ChebyshevYGrid2, 10);
    WriteDataSetToFile(F210E, EquidistantGrid2, EquidistantYGrid2, 10);
    WriteDataSetToFile(F210C, ChebyshevGrid2, ChebyshevYGrid2, 10);

    // Using ofstream for file writing
    ofstream F1N10EFile(F1N10E);
    ofstream F1N10CFile(F1N10C);
    ofstream F2N10EFile(F2N10E);
    ofstream F2N10CFile(F2N10C);

    ofstream F1N10E_E_File(F1N10E_E);
    ofstream F1N10C_E_File(F1N10C_E);
    ofstream F2N10E_E_File(F2N10E_E);
    ofstream F2N10C_E_File(F2N10C_E);


    for (int i = 0; i < 10000; i++) {
        // For the first grid
        double x = TestEquiGrid1[i];
        double y = TestYEquiGrid1[i];
        double xc = TestChebyshevGrid1[i];
        double yc = TestYChebyshevGrid1[i];

        double tmpl = NewtonInterpolationResultBackwards(x, EquidistantGrid, NTCoeff, 10);
        double tmplc = NewtonInterpolationResultBackwards(xc, ChebyshevGrid, NTCoeffC, 10);
        double tmple = fabs(y - tmpl);
        double tmplec = fabs(yc - tmplc);

        // Writing results to files
        F1N10EFile << x << " " << tmpl << "\n";
        F1N10CFile << xc << " " << tmplc << "\n";
        F1N10E_E_File << x << " " << tmple << "\n";
        F1N10C_E_File << xc << " " << tmplec << "\n";

        // For the second grid
        double x2 = TestEquiGrid2[i];
        double y2 = TestYEquiGrid2[i];
        double xc2 = TestChebyshevGrid2[i];
        double yc2 = TestYChebyshevGrid2[i];

        double tmpl2 = NewtonInterpolationResultBackwards(x2, EquidistantGrid2, NTCoeff2, 10);
        double tmplc2 = NewtonInterpolationResultBackwards(xc2, ChebyshevGrid2, NTCoeffC2, 10);
        double tmple2 = fabs(y2 - tmpl2);
        double tmplec2 = fabs(yc2 - tmplc2);

        // Writing results to files
        F2N10EFile << x2 << " " << tmpl2 << "\n";
        F2N10CFile << xc2 << " " << tmplc2 << "\n";
        F2N10E_E_File << x2 << " " << tmple2 << "\n";
        F2N10C_E_File << xc2 << " " << tmplec2 << "\n";
    }
    //
    // // Close files
    //
    const string F1_MAX_ERROR_EQU = "F1_MaxError_Equidistant.txt";
    const string F1_MAX_ERROR_CHEB = "F1_MaxError_Chebyshev.txt";
    const string F2_MAX_ERROR_EQU = "F2_MaxError_Equidistant.txt";
    const string F2_MAX_ERROR_CHEB = "F2_MaxError_Chebyshev.txt";

    ofstream F1MEFile(F1_MAX_ERROR_EQU);
    ofstream F1MCFile(F1_MAX_ERROR_CHEB);
    ofstream F2MEFile(F2_MAX_ERROR_EQU);
    ofstream F2MCFile(F2_MAX_ERROR_CHEB);


    double maxn = 0, maxl = 0, maxnc = 0, maxlc = 0;
    double maxn2 = 0, maxl2 = 0, maxnc2 = 0, maxlc2 = 0;
    double x, xc, tmpl, tmpn, tmplc, tmpnc, tmple, tmpne, tmplec, tmpnec, x2, xc2, tmpl2, tmpn2, tmplc2, tmpnc2, tmple2,
            tmpne2, tmplec2, tmpnec2, y, y2, yc, yc2;
    for (int i = 5; i <= 100; i++) {
        CreateEquidistantGrid(&EquidistantGrid, -2, 2, i);
        CreateChebyshevGrid(&ChebyshevGrid, -2, 2, i);
        CalcGridY(f1, &EquidistantGrid, &EquidistantYGrid, i);
        CalcGridY(f1, &ChebyshevGrid, &ChebyshevYGrid, i);
        CalculateNewtonCoefficientsBackwards(&NTCoeff, &EquidistantGrid, &EquidistantYGrid, i);
        CalculateNewtonCoefficientsBackwards(&NTCoeffC, &ChebyshevGrid, &ChebyshevYGrid, i);

        CreateEquidistantGrid(&EquidistantGrid2, -1, 1, i);
        CreateChebyshevGrid(&ChebyshevGrid2, -1, 1, i);
        CalcGridY(f2, &EquidistantGrid2, &EquidistantYGrid2, i);
        CalcGridY(f2, &ChebyshevGrid2, &ChebyshevYGrid2, i);
        CalculateNewtonCoefficientsBackwards(&NTCoeff2, &EquidistantGrid2, &EquidistantYGrid2, i);
        CalculateNewtonCoefficientsBackwards(&NTCoeffC2, &ChebyshevGrid2, &ChebyshevYGrid2, i);
        maxl = 0;
        maxlc = 0;
        maxl2 = 0;
        maxlc2 = 0;

        for (int k = 0; k < 10000; k++) {
            x = TestEquiGrid1[k];
            y = TestYEquiGrid1[k];
            xc = TestChebyshevGrid1[k];
            yc = TestYChebyshevGrid1[k];


            tmpl = NewtonInterpolationResultBackwards(x, EquidistantGrid, NTCoeff, i);

            tmplc = NewtonInterpolationResultBackwards(xc, ChebyshevGrid, NTCoeffC, i);
            tmple = fabs(y - tmpl);
            tmplec = fabs(yc - tmplc);
            if (maxl < tmple) maxl = tmple;
            if (maxlc < tmplec) maxlc = tmplec;

            x2 = TestEquiGrid2[k];
            y2 = TestYEquiGrid2[k];
            xc2 = TestChebyshevGrid2[k];
            yc2 = TestYChebyshevGrid2[k];
            tmpl2 = NewtonInterpolationResultBackwards(x2, EquidistantGrid2, NTCoeff2, i);
            tmplc2 = NewtonInterpolationResultBackwards(xc2, ChebyshevGrid2, NTCoeffC2, i);
            tmple2 = fabs(y2 - tmpl2);
            tmplec2 = fabs(yc2 - tmplc2);
            if (maxl2 < tmple2) maxl2 = tmple2;
            if (maxlc2 < tmplec2) maxlc2 = tmplec2;
        }
        F1MEFile << i << " " << fixed << setprecision(15) << maxl << "\n";
        F1MCFile << i << " " << fixed << setprecision(15) << maxlc << "\n";
        F2MEFile << i << " " << fixed << setprecision(15) << maxl2 << "\n";
        F2MCFile << i << " " << fixed << setprecision(15) << maxlc2 << "\n";
    }
    F1MEFile.close();
    F1MCFile.close();
    F2MEFile.close();
    F2MCFile.close();


    // Открытие файлов для записи результатов
    ofstream F1L1("Function1_Equidistant_Point1.txt");
    ofstream F1L1C("Function1_Chebyshev_Point1.txt");
    ofstream F1L2("Function1_Equidistant_Point2.txt");
    ofstream F1L2C("Function1_Chebyshev_Point2.txt");

    ofstream F2L1("Function2_Equidistant_Point1.txt");
    ofstream F2L1C("Function2_Chebyshev_Point1.txt");
    ofstream F2L2("Function2_Equidistant_Point2.txt");
    ofstream F2L2C("Function2_Chebyshev_Point2.txt");

    for (int i = 5; i <= 100; i++) {
        // Функция 1
        CreateEquidistantGrid(&EquidistantGrid, -2,2, i);
        CreateChebyshevGrid(&ChebyshevGrid, -2,2, i);
        CalcGridY(f1, &EquidistantGrid, &EquidistantYGrid, i);
        CalcGridY(f1, &ChebyshevGrid, &ChebyshevYGrid, i);
        CalculateNewtonCoefficientsBackwards(&NTCoeff, &EquidistantGrid, &EquidistantYGrid, i);
        CalculateNewtonCoefficientsBackwards(&NTCoeffC, &ChebyshevGrid, &ChebyshevYGrid, i);

        // Функция 2
        CreateEquidistantGrid(&EquidistantGrid2, -1,1, i);
        CreateChebyshevGrid(&ChebyshevGrid2, -1,1, i);
        CalcGridY(f2, &EquidistantGrid2, &EquidistantYGrid2, i);
        CalcGridY(f2, &ChebyshevGrid2, &ChebyshevYGrid2, i);
        CalculateNewtonCoefficientsBackwards(&NTCoeff2, &EquidistantGrid2, &EquidistantYGrid2, i);
        CalculateNewtonCoefficientsBackwards(&NTCoeffC2, &ChebyshevGrid2, &ChebyshevYGrid2, i);

        // Точки для функции 1
        x = TestEquiGrid1[3000];
        y = TestYEquiGrid1[3000];
        xc = TestChebyshevGrid1[3000];
        yc = TestYChebyshevGrid1[3000];
        tmpl = NewtonInterpolationResultBackwards(x, EquidistantGrid, NTCoeff, i);
        tmplc = NewtonInterpolationResultBackwards(xc, ChebyshevGrid, NTCoeffC, i);
        tmple = fabs(y - tmpl);
        tmplec = fabs(yc - tmplc);

        // Точки для функции 2
        x2 = TestEquiGrid2[3000];
        y2 = TestYEquiGrid2[3000];
        xc2 = TestChebyshevGrid2[3000];
        yc2 = TestYChebyshevGrid2[3000];
        tmpl2 = NewtonInterpolationResultBackwards(x2, EquidistantGrid2, NTCoeff2, i);
        tmplc2 = NewtonInterpolationResultBackwards(xc2, ChebyshevGrid2, NTCoeffC2, i);
        tmple2 = fabs(y2 - tmpl2);
        tmplec2 = fabs(yc2 - tmplc2);

        // Вывод результатов
        F1L1 << i << "," << setprecision(15) << tmple << "\n";
        F1L1C << i << "," << setprecision(15) << tmplec << "\n";
        F2L1 << i << "," << setprecision(15) << tmple2 << "\n";
        F2L1C << i << "," << setprecision(15) << tmplec2 << "\n";

        // Вторая точка для функции 1
        x = TestEquiGrid1[8000];
        y = TestYEquiGrid1[8000];
        xc = TestChebyshevGrid1[8000];
        yc = TestYChebyshevGrid1[8000];
        tmpl = NewtonInterpolationResultBackwards(x, EquidistantGrid, NTCoeff, i);
        tmplc = NewtonInterpolationResultBackwards(xc, ChebyshevGrid, NTCoeffC, i);
        tmple = fabs(y - tmpl);
        tmplec = fabs(yc - tmplc);

        // Вторая точка для функции 2
        x2 = TestEquiGrid2[8000];
        y2 = TestYEquiGrid2[8000];
        xc2 = TestChebyshevGrid2[8000];
        yc2 = TestYChebyshevGrid2[8000];
        tmpl2 = NewtonInterpolationResultBackwards(x2, EquidistantGrid2, NTCoeff2, i);
        tmplc2 = NewtonInterpolationResultBackwards(xc2, ChebyshevGrid2, NTCoeffC2, i);
        tmple2 = fabs(y2 - tmpl2);
        tmplec2 = fabs(yc2 - tmplc2);

        // Вывод результатов для второй точки
        F1L2 << i << "," << setprecision(15) << tmple << "\n";
        F1L2C << i << "," << setprecision(15) << tmplec << "\n";
        F2L2 << i << "," << setprecision(15) << tmple2 << "\n";
        F2L2C << i << "," << setprecision(15) << tmplec2 << "\n";

    }

    // Печать контрольных точек
    cout << "Точка 1 равномерн. функция 1: " << setprecision(15) << TestEquiGrid1[3000] << "\n";
    cout << "Точка 1 чебышев. функция 1: " << setprecision(15) << TestChebyshevGrid1[3000] << "\n";
    cout << "Точка 2 равномерн. функция 1: " << setprecision(15) << TestEquiGrid1[8000] << "\n";
    cout << "Точка 2 чебышев. функция 1: " << setprecision(15) << TestChebyshevGrid1[8000] << "\n";
    cout << "Точка 1 равномерн. функция 2: " << setprecision(15) << TestEquiGrid2[3000] << "\n";
    cout << "Точка 1 чебышев. функция 2: " << setprecision(15) << TestChebyshevGrid2[3000] << "\n";
    cout << "Точка 2 равномерн. функция 2: " << setprecision(15) << TestEquiGrid2[8000] << "\n";
    cout << "Точка 2 чебышев. функция 2: " << setprecision(15) << TestChebyshevGrid2[8000] << "\n";


    return 0;
}
