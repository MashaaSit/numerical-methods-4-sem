% Загрузка данных
error_vs_eps = load('/home/masha/numerical_methods/lab10/lab10_proj/cmake-build-debug/error_vs_eps.txt');
iterations_vs_eps = load('/home/masha/numerical_methods/lab10/lab10_proj/cmake-build-debug/iterations_vs_eps.txt');
error_vs_length = load('/home/masha/numerical_methods/lab10/lab10_proj/cmake-build-debug/error_vs_length.txt');
grid_data = load('/home/masha/numerical_methods/lab10/lab10_proj/cmake-build-debug/integration_grid.txt');

% График зависимости ошибки от точности с линией биссектрисы
figure;
loglog(error_vs_eps(:,1), error_vs_eps(:,2), 'b-', 'LineWidth', 2);
hold on;
loglog(error_vs_eps(:,1), error_vs_eps(:,1), 'r--', 'LineWidth', 2);  % Линия биссектрисы
xlabel('Заданная точность');
ylabel('Ошибка');
legend('Ошибка', 'Биссектриса');
grid on;
title('Зависимость ошибки от заданной точности');

% График зависимости числа итераций от точности
figure;
semilogx(iterations_vs_eps(:,1), iterations_vs_eps(:,2), 'b-', 'LineWidth', 2);
xlabel('Заданная точность');
ylabel('Число итераций');
grid on;
title('Зависимость числа итераций от заданной точности');

% Логарифмирование данных по основанию 2
log_length = log(error_vs_length(:,1));  % Длина отрезков
log_error = log(error_vs_length(:,2));   % Ошибка

% Построение графика
figure;
plot(log_length, log_error, 'b-', 'LineWidth', 2);
xlabel('Длина отрезка разбиения (log2)');
ylabel('Фактическая ошибка (log2)');
grid on;
title('Зависимость фактической ошибки от длины отрезка разбиения');

% Линейная регрессия для определения порядка точности и константы
p = polyfit(log_length, log_error, 1);     % Линейная регрессия
order_of_accuracy = p(1);                  % Порядок точности
constant = 2^p(2);                         % Константа

% Вывод результатов
fprintf('Порядок точности: %f\n', order_of_accuracy);
fprintf('Константа: %f\n', constant);

