#include <iostream>
#include <fstream>
#include <cmath>
#include <vector>
#include <iomanip>
using namespace std;

double f(double x) {
    return pow(x, 4) - 9.2 * pow(x, 3) + 5.5 * pow(x, 2) - 7 * x - 1.4;
}

double method_38(double a, double b, int N, vector<double>& f_values) {
    double h = (b - a) / N;
    double integral = f_values[0] + f_values[N];

    for (int k = 1; k < N; ++k) {
        if (k % 3 == 0) {
            integral += 2 * f_values[k];
        } else {
            integral += 3 * f_values[k];
        }
    }

    return (3.0 / 8.0) * h * integral;
}

double runge_rule(double I1, double I2) {
    return abs(I2 - I1) / 15.0;
}

double integrate(double a, double b, double eps, ofstream &grid_output, int &iterations, double &segment_length) {
    int n = 3;
    double h = (b - a) / n;
    vector<double> f_values(n + 1);

    for (int i = 0; i <= n; ++i) {
        f_values[i] = f(a + i * h);
    }

    double I1 = method_38(a, b, n, f_values), I2 = 0;
    iterations = 0;

    do {
        I2 = I1;
        n *= 2;
        h = (b - a) / n;

        vector<double> new_f_values(n + 1);

        int j = 0;
        for (int i = 0; i <= n; i += 2) {
            new_f_values[i] = f_values[j++];
        }
        double z = a;
        double h_2 = 2*h;
        for (int i = 1; i < n; i += 2) {

            new_f_values[i] = f(z);
            z+=h_2;
        }

        f_values = std::move(new_f_values);

        I1 = method_38(a, b, n, f_values);
        iterations++;

    } while (runge_rule(I1, I2) > eps);

    segment_length = h;

    for (int i = 0; i <= n; ++i) {
        grid_output << setprecision(10) << a + i * h << " " << f_values[i] << "\n";
    }

    return I1;
}

int main() {
    double a = -1, b = 1;
    vector eps_values = {1e-3, 1e-4, 1e-5, 1e-6, 1e-7, 1e-8, 1e-9, 1e-10, 1e-11, 1e-12};

    ofstream grid_output("integration_grid.txt"), error_output("error_vs_eps.txt"), iter_output("iterations_vs_eps.txt"), length_output("error_vs_length.txt");
    double true_value = 19.0 / 15.0;
    vector<double> actual_errors, lengths;

    for (double eps : eps_values) {
        int iterations = 0;
        double segment_length = 0.0;
        double approx_value = integrate(a, b, eps, grid_output, iterations, segment_length);
        double actual_error = abs(approx_value - true_value);

        error_output << setprecision(10) << eps << " " << actual_error << "\n";
        iter_output << setprecision(10) << eps << " " << iterations << "\n";
        length_output << setprecision(10) << segment_length << " " << actual_error << "\n";

        actual_errors.push_back(actual_error);
        lengths.push_back(segment_length);
    }

    grid_output.close();
    error_output.close();
    iter_output.close();
    length_output.close();

    cout << "Результаты сохранены в файлы.\n";
    return 0;
}
