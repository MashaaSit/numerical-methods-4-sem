#include <fstream>
#include <iomanip>
#include <cmath>
#include <iostream>

using namespace std;

long double f(long double x, long double y) {
    return (3 * pow(x, 2) * exp(-x) - (x + 1) * y) / x;
}

void modified_euler(long double a, long double b, long double y0, int N, long double eps, const string &filename) {
    long double h = (b - a) / N;
    long double x = a;
    long double y = y0;
    long double h_max = 0.1;
    long double h_min = 1e-7;
    ofstream file(filename);

    if (!file.is_open()) {
        cerr << "Error opening file!" << endl;
        return;
    }


    if (eps == 0) {
        file << x << "\t" << y << "\n";

        for (int i = 1; i <= N; ++i) {
            long double y_mid = y + h / 2 * f(x, y);
            long double f_xh_y_mid = f(x + h / 2, y_mid);
            y = y + h * f_xh_y_mid;
            x += h;
            file << x << "\t" << y << "\n";
        }
    } else {
        h = 0.5;
        double f_xy = f(x,y);
        file << x << "\t" << y << "\t" << h << "\n";

        while (x < b) {
            long double y_mid = y + h / 2 * f_xy;
            long double y_next_h = y + h * f(x + h / 2, y_mid);

            long double y_mid_2 = y + (h / 2) * f_xy;
            long double y_next_h_2 = y_mid_2 + (h / 2) * f(x + (h / 2), y_mid_2);

            long double runge_error = fabs(y_next_h - y_next_h_2) / 3.0;

            if (runge_error < eps / 10) {
                x += h;
                y = y_next_h;
                file << x << "\t" << y << "\t" << h << "\n";
                h = min(h * 2.0, h_max);
                f_xy = f(x,y);
            } else if (runge_error < eps) {
                x += h;
                y = y_next_h;
                file << x << "\t" << y << "\t" << h << "\n";
                f_xy = f(x,y);
            } else {
                h = max(h * 0.5, h_min);
            }
        }
    }

    file.close();
}

int main() {
    long double a = 1.0;
    long double y0 = 1 / exp(1);
    long double b = 5.0;

    modified_euler(a, b, y0, 10, 0, "euler_fixed_10.txt");
    modified_euler(a, b, y0, 100, 0, "euler_fixed_100.txt");

    long double eps = 0.1;
    for (int i = 0; i < 8; i++) {
        ostringstream stream;
        stream << fixed << setprecision(8) << eps;
        string filename = "euler_" + stream.str() + ".txt";
        modified_euler(a, b, y0, 0, eps, filename);
        eps *= 0.1;
    }

    return 0;
}
