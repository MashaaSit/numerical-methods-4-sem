function retval = y_exact(x)
    retval = x.^2.* exp(-x);
end
