% Define exact solution function
y_exact = @(x) x.^2 .* exp(-x);

% List of Euler and Adam-Bashforth files
euler_files = {'/home/masha/numerical_methods/kursach/cmake-build-debug/euler_0.10000000.txt', ...
               '/home/masha/numerical_methods/kursach/cmake-build-debug/euler_0.01000000.txt', ...
               '/home/masha/numerical_methods/kursach/cmake-build-debug/euler_0.00100000.txt', ...
               '/home/masha/numerical_methods/kursach/cmake-build-debug/euler_0.00010000.txt', ...
               '/home/masha/numerical_methods/kursach/cmake-build-debug/euler_0.00001000.txt', ...
               '/home/masha/numerical_methods/kursach/cmake-build-debug/euler_0.00000100.txt', ...
               '/home/masha/numerical_methods/kursach/cmake-build-debug/euler_0.00000010.txt'};

adam_files = {'/home/masha/numerical_methods/kursach/cmake-build-debug/adams_0.10000000.txt', ...
              '/home/masha/numerical_methods/kursach/cmake-build-debug/adams_0.01000000.txt', ...
              '/home/masha/numerical_methods/kursach/cmake-build-debug/adams_0.00100000.txt', ...
              '/home/masha/numerical_methods/kursach/cmake-build-debug/adams_0.00010000.txt', ...
              '/home/masha/numerical_methods/kursach/cmake-build-debug/adams_0.00001000.txt', ...
              '/home/masha/numerical_methods/kursach/cmake-build-debug/adams_0.00000100.txt', ...
              '/home/masha/numerical_methods/kursach/cmake-build-debug/adams_0.00000010.txt'};

% Initialize arrays to store errors and function calls
error_euler = zeros(1, length(euler_files));
calls_euler = zeros(1, length(euler_files));
error_adam = zeros(1, length(adam_files));
calls_adam = zeros(1, length(adam_files));

% Loop over all files to compute the errors and function calls
for i = 1:length(euler_files)
    % Load data from Euler and Adams files
    data_euler = load(euler_files{i});
    data_adam = load(adam_files{i});

    % Compute the errors for Euler method
    error_euler(i) = max(abs(data_euler(:,2) - y_exact(data_euler(:,1))));

    % Compute the errors for Adams-Bashforth method
    error_adam(i) = max(abs(data_adam(:,2) - y_exact(data_adam(:,1))));

    % Get the maximum number of function calls for each method
    calls_euler(i) = max(data_euler(:,3));
    calls_adam(i) = max(data_adam(:,3));
end

% Plot the errors vs the number of function calls on a log-log scale
figure;
loglog(calls_euler, error_euler, 'bo-', 'DisplayName', 'Euler Method');
hold on;
loglog(calls_adam, error_adam, 'ro-', 'DisplayName', 'Adam-Bashforth Method');
hold off;

% Set plot labels and title
xlabel('Количество вызовов правой части');
ylabel('Погрешность');
title('Зависимость погрешности от количества вызовов правой части');
legend;
grid on;

